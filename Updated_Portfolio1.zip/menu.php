<section style="background:black;">

    <div class="container-fluid">
        <div class="row">
            <div class="col-md-2 col-6">
                <div class="logo">
                    <img src="images/png/logo-no-background.png" width="100%" alt="">
                </div>
            </div>
            <div class="col-md-9 top-menu">
                <div class="pages">
                    <ul>
                        <li>Home</li>
                        <a href="menu.php"><li>About</li></a>
                        <li>Services</li>
                        <li>Contact</li>
                        <li>Login</li>
                    </ul>
                </div>
            </div>

            <style>
                .footer-social .sidebar-fa {
                    box-shadow: 50px 50px 100px #fff,
                        -50px -50px 100px #fff;
                }
            </style>

            <div class="col-md-1 col-6 sidebar-btn">
                <div class="sidebar-icon">
                    <div class="w3-teal">
                        <button class="w3-button w3-teal w3-xlarge w3-right" onclick="openRightMenu()">&#9776;</button>
                    </div>
                    <div class="w3-sidebar w3-bar-block w3-card w3-animate-right" style="display:none;right:0;"
                        id="rightMenu">
                        <button onclick="closeRightMenu()" class="w3-bar-item w3-button w3-large"
                            style="text-align:right;"><i class="fa-regular fa-circle-xmark"></i></button>
                        <center>
                            <h2 style="letter-spacing:1px;font-weight:600;font-size:50px;margin-top:30px;">"PROJECTS"</h2>
                            <h2 style="letter-spacing:1px;font-weight:600;font-size:50px;">"CONTACT"</h2>
                            <h2 style="letter-spacing:1px;font-weight:600;font-size:50px;">"WORLD"</h2>
                        </center>

                        <center>
                            <div class="footer-social mt-5">
                                <i class="fa-brands sidebar-fa fa-instagram"></i>
                                <i class="fa-brands sidebar-fa fa-facebook"></i>
                                <i class="fa-brands sidebar-fa fa-linkedin-in"></i>
                                <i class="fa-brands sidebar-fa fa-github"></i>
                            </div>
                        </center>
                        <center>
                            <div class="ftrtxt1" style="color:black;">
                                <h3>CONTACT ME</h3>
                                <p style="letter-spacing: 1px;">kumarharshit6206@gmail.com</p>
                                <p class="ftrp">Copyright ©2024 All rights reserved | This website is made by Harshit
                                </p>
                            </div>
                        </center>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

