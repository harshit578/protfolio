<section class="footer">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <center>
                    <div class="footer-social">
                        <i class="fa-brands fa-instagram"></i>
                        <i class="fa-brands fa-facebook"></i>
                        <i class="fa-brands fa-linkedin-in"></i>
                        <i class="fa-brands fa-github"></i>
                    </div>
                </center>
                <center>
                    <div class="ftrtxt1">
                        <h3>CONTACT ME</h3>
                        <p style="letter-spacing: 1px;">kumarharshit6206@gmail.com</p>
                        <p class="ftrp">Copyright ©2024 All rights reserved | This website is made by Harshit</p>
                    </div>
                </center>
            </div>
        </div>
    </div>
</section>